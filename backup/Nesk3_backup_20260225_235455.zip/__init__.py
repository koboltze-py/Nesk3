"""Funktionen-Paket: Geschäftslogik"""
