"""GUI-Paket: PySide6 Benutzeroberfläche"""
